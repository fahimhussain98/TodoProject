package com.example.projectnew

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projectnew.databinding.ActivityMainBinding
import com.example.projectnew.databinding.DialogAddUserBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val userViewModel: UserViewModel by viewModels()
    private val userAdapter = UserAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
        loadUsers()
    }

    private fun setupRecyclerView() {
        binding.recyclerView.apply {
            adapter = userAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
    }

    private fun setupClickListeners() {
        binding.fabAddUser.setOnClickListener {
            showAddUserDialog()
        }
    }

    private fun showAddUserDialog() {
        val dialog = AlertDialog.Builder(this)
        val dialogBinding = DialogAddUserBinding.inflate(layoutInflater)

        dialog.setView(dialogBinding.root)
            .setTitle("Add New User")
            .setPositiveButton("Add") { _, _ ->
                val title = dialogBinding.etTitle.text.toString()
                val description = dialogBinding.etDescription.text.toString()

                if (title.isNotEmpty() && description.isNotEmpty()) {
                    val user = User(Title = title, Description = description)
                    userViewModel.addUser(user)
                    loadUsers()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadUsers() {
        lifecycleScope.launch {
            val users = userViewModel.getAllUsers()
            userAdapter.setData(users)
        }
    }
}